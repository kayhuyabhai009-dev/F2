This is a placeholder file for platform-35_r02.zip.
Because the original SDK platform is approximately 64MB and contains binaries, this file has been generated locally as requested.
To use the actual Android SDK platform components, please download the original archive from the official Google server using your terminal:
wget https://dl.google.com/android/repository/platform-35_r02.zip
